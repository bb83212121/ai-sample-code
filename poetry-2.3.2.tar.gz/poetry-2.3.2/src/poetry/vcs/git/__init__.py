from __future__ import annotations

from poetry.vcs.git.backend import Git


__all__ = ["Git"]
